# MasterMind

## Installation

``pip install AnumbyRobotSJ=1.0.0``

# Comment utiliser ?

# License

Copyright 2023 Chris Arnault

This repository is licensed under the MIT license.
See LICENSE for details
