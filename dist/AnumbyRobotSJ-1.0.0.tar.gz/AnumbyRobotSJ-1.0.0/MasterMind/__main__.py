
def main():
    print("MasterMind")
    
if __name__ == "__main__":
    main()
